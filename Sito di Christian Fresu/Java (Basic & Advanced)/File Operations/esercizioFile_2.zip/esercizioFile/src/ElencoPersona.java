import java.util.ArrayList;

public class ElencoPersona {

    static final int n = 5;

    ArrayList<Persona> Elenco;


    public ElencoPersona() {
        Elenco = new ArrayList<Persona>();
    }

    public int getNumElementi() {
        return Elenco.size();
    }


    public void aggiungiPersona(Persona p) {
        Elenco.add(p);
    }

    public String Visualizza() {
        String s = "";
        int i;
        for (i = 0; i < Elenco.size(); i++)
            s = s + Elenco.get(i).VisualizzaSingolaPersona() + "\n";
        return s;
    }


    public Persona panziano() {
        int posMax = 0;
        int max = Elenco.get(0).getEta();
        for (int i = 0; i < Elenco.size(); i++) {
            if (max < Elenco.get(i).getEta()) {
                max = Elenco.get(i).getEta();
                posMax = i;
            }
        }

        return Elenco.get(posMax);
    }

    public float meta() {
        float media = 0;
        for (int i = 0; i < Elenco.size(); i++) {
            media = media + Elenco.get(i).getEta();
        }
        return (media / Elenco.size());
    }

    public ArrayList<Persona> metasup() {
        float m = meta();
        ArrayList<Persona> sopraMedia = new ArrayList<>();

        for (int i = 0; i < Elenco.size(); i++) {
            if (Elenco.get(i).getEta() > m) {
                sopraMedia.add(Elenco.get(i));
            }

        }
        return sopraMedia;
    }

    public float meta(char sesso) {
        float media = 0;
        float c = 0;
        for (int i = 0; i < Elenco.size(); i++) {
            if (Elenco.get(i).getSesso() == sesso) {
                media = media + Elenco.get(i).getEta();
                c++;
            }
        }
        return (media / c);
    }
}