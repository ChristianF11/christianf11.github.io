import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Gestione {
    public static void main(String[] args) throws IOException {
        String parolette[];
        Scanner input = new Scanner(System.in);
        BufferedReader fileinput = new BufferedReader(new FileReader("FileInput/Elenco.txt"));
        String parola;
        ArrayList<Persona> sup = new ArrayList<>();
        Persona p;
        ElencoPersona el=new ElencoPersona();
        int scelta;
        do{
            System.out.println("MENU'");
            System.out.println("1.Leggi da file");
            System.out.println("2.Visualizza");
            System.out.println("3.Determina persona più anziana");
            System.out.println("4.Visualizza le persone che superano l'età media");
            System.out.println("5.Determina la media dell'età per i maschi");
            System.out.println("6.Determina la media dell'età per le femmine");
            System.out.println("7.Calcola la percentuale dei maschi e delle femmine");
            System.out.println("7.Ricerca per cognome");
            System.out.println("8.Uscita");
            System.out.println("\nOnserire la scelta: ");



            scelta= input.nextInt();
            switch (scelta)
            {
                case 1:  //lettura da file
                    parola=fileinput.readLine();
                    while(parola!=null){

                        parolette=parola.split(" ");


                        p=new Persona(parolette[0],parolette[1],Integer.parseInt(parolette[2]),parolette[3].charAt(0));
                        el.aggiungiPersona(p);
                        parola=fileinput.readLine();

                    }
                    System.out.println("Caricamento dei dati eseguito");
                    break;

                case 2:
                    if(el.getNumElementi()!=0)
                        System.out.println(el.Visualizza());
                    else
                        System.out.println("Attenzione! E' necessario caricare prima i dati dal file! Premi il tasto 1!!!!");
                    break;

                case 3:
                    Persona anz=new Persona();
                    anz=el.panziano();
                    System.out.println("La persona piu' anziana dell'elenco e': " + anz.VisualizzaSingolaPersona());
                    break;

                case 4:
                    System.out.println("L'eta' media delle persone e' : \n" + el.meta());
                    System.out.println("Le persone che superano la media sono: \n");
                    sup=el.metasup();
                    for(int i=0; i<sup.size(); i++){
                        System.out.println(sup.get(i).VisualizzaSingolaPersona());
                    }

                    break;

                case 5:
                    System.out.println("L'eta' media dei maschi e' : \n" + el.meta('M'));

                    break;

                case 6:
                    System.out.println("L'eta' media delle femmine e' : \n" + el.meta('F'));

                    break;

                case 7:
                    break;

                case 8:
                    System.out.println("Stai per terminare il programma!Grazie!");
                    fileinput.close();
                    break;

                default:
                    System.out.println("Hai sbagliato scelta!");
            }
        }while(scelta!=8);




    }
}